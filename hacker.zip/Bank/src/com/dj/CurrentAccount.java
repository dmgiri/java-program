package com.dj;

public class CurrentAccount extends Account {
	double checkbalance;

	public CurrentAccount() {
		balance = 10000;
	}

	@Override
	public void withdraw(double amount) {
		if (amount > 250000) {
			checkbalance = balance - amount;
			if (checkbalance >= 0) {
				balance = balance - amount;
				System.out.println("thank you");
				System.out.println("your cuurent balance is " + balance);
			} else {
				System.out.println("sorry sir, insufficient balance");
			}
		}
		else{
			System.out.println("please enter valid ammount");
		}
	}
}

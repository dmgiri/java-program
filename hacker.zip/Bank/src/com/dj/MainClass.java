package com.dj;

import java.util.Scanner;

public class MainClass {
	
	public static void main(String[] args) {
		
		double amount;
 		Account savingacount=new CurrentAccount();
		savingacount.balance();
		
		Scanner in = new Scanner(System.in);
		System.out.println("enter the ammount for deposite ");
		amount=in.nextDouble();		
		savingacount.deposite(amount);
		savingacount.balance();
		System.out.println("enter the amount for withdraw");
		amount=in.nextDouble();
		savingacount.withdraw(amount);
		savingacount.balance();
		
	}

}

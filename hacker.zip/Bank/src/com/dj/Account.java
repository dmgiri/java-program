package com.dj;

import javax.swing.plaf.basic.BasicLabelUI;

import org.omg.CORBA.BAD_QOS;

public abstract class Account {
	double balance;
	public Account() {
		balance=10000;
	}

	double checkbalance;
	
	public void deposite(double amount) {
		balance = balance + amount;
	}


	public void withdraw(double amount) {
		checkbalance= balance-amount;
		if(checkbalance>=10000){
			balance=balance-amount;
			System.out.println("thank you");
		}
		else {
			System.out.println("sorry sir, insufficient balance");
		}
	}

	
	public void balance() {
		System.out.println("current balance "+balance+ " Rs.");
	}
	
	
	public void data(double amount){};
	
}

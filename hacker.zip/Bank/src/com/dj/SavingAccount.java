package com.dj;

public class SavingAccount extends Account {
	double checkbalance;
	boolean frozon = false;
	int month = 0;

	public SavingAccount() {
		balance = 10000;
	}

	public void balance() {
		System.out.println("current balance " + balance + " Rs.");
	}

	public void frozonAccount() {
		month = 3;
		if (month > 1) {
			frozon = true;
		}
		if (frozon == true) {
			System.out.println("account frozon...\n please contact your nearest bank ");
		}
	}

	public void openFrozon() {
		frozon=false;
		System.out.println("account open"); 
	}
}

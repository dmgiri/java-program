package com.dj;

public class SalaryAccount extends Account {
	
	public SalaryAccount() {
		balance=10000;
	}

}
